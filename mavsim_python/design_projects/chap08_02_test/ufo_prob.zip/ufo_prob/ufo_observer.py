# ufo_ekf.py
import numpy as np
from math import fmod

class EkfStateObserver:
    # implement continuous-discrete EFK for UFO
    def __init__(self):
        # define model parameters
        self.m = 
        self.b0 = 
        self.b1 = 
        self.g = 
        self.Ts = 
        # process and measurement noise
        self.Q = 
        self.R = 
        # initialize state and covariance
        self.vel0 = 
        self.pos0 = 
        self.xhat = np.array([ [self.vel0], [self.pos0] ])
        self.Px = 

    def update(self,inp):
        # ekf algorithm for ufo
        F = inp[0]
        z_m = inp[1]
        t = inp[2]

        # prediction step
        N = 10
        for j in range(0, N):
            

        # correction step
        

        # return state estimate
        return self.xhat